using System;
using Domain.Entities;
using Domain.Result;

namespace Application.Services.Template;

public class TemplateService
{

    #region Get

    public Result<TemplateEntity> GetAsync(Guid id)
    {
        throw new NotImplementedException();
    }
    #endregion

    #region Post
    public Result<TemplateEntity> PostAsync(Guid id)
    {
        throw new NotImplementedException();
    }
    #endregion
}

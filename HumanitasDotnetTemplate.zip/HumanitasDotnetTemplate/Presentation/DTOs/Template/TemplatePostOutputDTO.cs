using System;

namespace Presentation.DTOs;

public class TemplatePostOutputDTO
{
    public Guid Id {get; set;}
    public string Description {get; set;}
}

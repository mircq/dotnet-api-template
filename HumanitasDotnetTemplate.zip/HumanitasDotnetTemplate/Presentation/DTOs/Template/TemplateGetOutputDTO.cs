using System;

namespace Presentation.DTOs;

public class TemplateGetOutputDTO
{

    public Guid Id { get; set; }

    public string Description { get; set; }
}
